package com.liferay.assignment.registration.portlet.constants;

/**
 * @author Argil DX
 */
public class RegistrationPortletKeys {

	public static final String REGISTRATION =
		"com_liferay_assignment_registration_portlet_RegistrationPortlet";

}